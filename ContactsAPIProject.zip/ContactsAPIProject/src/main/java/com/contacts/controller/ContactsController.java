package com.contacts.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.contacts.model.*;
import com.contacts.repository.ContactsRepository;
import com.contacts.service.ContactsService;

@RestController
@RequestMapping("")
public class ContactsController {
	
	
	@Autowired
	ContactsService contactsService;

	@PostMapping("/recordContactDetails")
	public ResponseEntity<Contacts> createContact(@RequestBody Contacts contacts) {
		
		ResponseEntity<Contacts> savedContactResponse = contactsService.save(contacts);
		
		return savedContactResponse;
	}

	
	@GetMapping("retrieveContactDetails/{id}")
	public ResponseEntity<Contacts> getContractById(@PathVariable("id") long id) {
		
		ResponseEntity<Contacts> foundContactResponse = contactsService.getById(id);
		
		return foundContactResponse;
	}

}
