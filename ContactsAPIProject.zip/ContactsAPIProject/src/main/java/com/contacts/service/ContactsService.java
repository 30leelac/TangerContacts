package com.contacts.service;

import org.springframework.http.ResponseEntity;

import com.contacts.model.Contacts;


public interface ContactsService {
	
	ResponseEntity<Contacts> getById(Long id);
	ResponseEntity<Contacts> save(Contacts contact);

}
