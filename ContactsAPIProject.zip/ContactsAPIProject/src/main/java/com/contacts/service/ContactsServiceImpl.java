package com.contacts.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.contacts.model.Contacts;
import com.contacts.repository.ContactsRepository;

@Service
public class ContactsServiceImpl implements ContactsService{
	
	@Autowired
	private ContactsRepository contactsRepository;
	
	@Override
	public ResponseEntity<Contacts> save(Contacts contact) {
		try {
			Contacts _contacts = contactsRepository
					.save(new Contacts(contact.getName(), contact.getPhoneNumber()));
			return new ResponseEntity<>(_contacts, HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@Override
	public ResponseEntity<Contacts> getById(Long id) {
		Optional<Contacts> contactsData = contactsRepository.findById(id);

		if (contactsData.isPresent()) {
			return new ResponseEntity<>(contactsData.get(), HttpStatus.OK);
		} else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}

	


}
