package com.contacts.repository;
import com.contacts.model.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactsRepository extends JpaRepository<Contacts, Long> {
	 
	

}
