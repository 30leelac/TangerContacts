package com.contacts.client.controller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.contacts.client.model.Contacts;

import jakarta.validation.Valid;

@Controller
public class ContactsController {

	@GetMapping("/index")
	public String showPage(Model model) {
	    model.addAttribute("contacts", new Contacts());
	    model.addAttribute("findContact", new Contacts());
	    return "index";
	}
	
	@PostMapping("/recordContactDetails")
    public String recordContactDetails(@ModelAttribute("contacts") Contacts contacts, BindingResult result, Model model) {
     
	if (!contacts.getName().isEmpty() && !contacts.getPhoneNumber().isEmpty()) {
	 String recordUri = "http://localhost:8080/recordContactDetails";
     
     HttpHeaders headers = new HttpHeaders();
     HttpEntity<Contacts> entity = new HttpEntity<>(contacts, headers);
     RestTemplate restTemplate = new RestTemplate();
     ResponseEntity<Contacts> responseContacts = restTemplate.exchange(recordUri, HttpMethod.POST, entity,
    		 Contacts.class);
     
     Contacts createdContact = new Contacts();
     if (responseContacts.getStatusCode() == HttpStatus.CREATED) {
    	 
    	 createdContact = responseContacts.getBody();
    	 
    	 model.addAttribute("createdContact", createdContact);
     }
     
	}
	else {
		 model.addAttribute("errormsg1",  new String("Missing Required Fields"));
	}
	    model.addAttribute("contacts", new Contacts());
	    model.addAttribute("findContact", new Contacts());
	 return "index";
    }
	
	
	@GetMapping("/retrieveContactDetails")
    public String updateForm(@ModelAttribute("findContact") Contacts findContact, Model model) {
		String retrieveUri = "http://localhost:8080/retrieveContactDetails/";
	     
		if (null!=findContact.getId()) {
	     HttpHeaders headers = new HttpHeaders();
	     HttpEntity<Contacts> entity = new HttpEntity<>(null, headers);
	     RestTemplate restTemplate = new RestTemplate();
	     
	     try {
		     ResponseEntity<Contacts> responseContacts = restTemplate.exchange(retrieveUri+findContact.getId(), HttpMethod.GET, entity,
		    		 Contacts.class);
		     
		     Contacts foundContact = null;
		     if (responseContacts.getStatusCode() == HttpStatus.OK) {
		    	 
		    	 foundContact = responseContacts.getBody();
		    	 
		    	 model.addAttribute("foundContact", foundContact);
		    	 
		     }
		} catch (HttpClientErrorException e) {
		      System.out.println(e.getStatusCode());
		      model.addAttribute("errormsg2",  new String("Contact Not Found"));
		  }
	    
		    model.addAttribute("contacts", new Contacts());
		    model.addAttribute("findContact", new Contacts());
	     
		}
        return "index";
    }
 

}
