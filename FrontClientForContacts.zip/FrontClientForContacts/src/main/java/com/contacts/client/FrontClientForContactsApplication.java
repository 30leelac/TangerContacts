package com.contacts.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontClientForContactsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrontClientForContactsApplication.class, args);
	}

}
